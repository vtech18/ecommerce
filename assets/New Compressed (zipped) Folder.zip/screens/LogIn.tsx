 import React, { useState } from "react";
 import { View,Text,StyleSheet,Button,StatusBar, TextInput,ScrollView} from "react-native";

 export default function LogIn()
 {
  const [isNewUser,setIsNewUSer]=useState(false);
  const [isOldUser,setIsOldUSer]=useState(false);
   
  const handleLogIn=():void=>
  {
    return setIsNewUSer(true);
  }
  const handleSignIn=():void=>
  {
    return setIsOldUSer(true);
  }
  const handleBack=()=>
  {
    setIsOldUSer(false);
    setIsNewUSer(false);
  }
    return(
      <>
         
        <View style={styles.container}>
        <StatusBar barStyle='light-content' />
        <View style={styles.container1} >
        {(isNewUser || isOldUser)?console.log('ji'): 
        <>
        <Button title="Log In" onPress={handleLogIn} />
        <Button title="sign up" onPress={handleSignIn} />
        </>
        }

      {isNewUser?
      <TextInput placeholder="name" />:''}

        </View>
        <View>
        <Button onPress={handleBack} title="back"/>
        </View>
          </View>
         </>
    )
 }
 const styles = StyleSheet.create(
    {
        container:
        {
            flex:1,
            backgroundColor:'red',
        },
        container1:
        {
             width:'100%',
             height:'80%',
            backgroundColor:'red',
        },
        container2:
        {
           width:'100%',
           height:'20%',
            backgroundColor:'red',
            alignItems:"flex-end",
        }
    }
 )