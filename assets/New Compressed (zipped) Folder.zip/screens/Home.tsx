import React, { Component } from 'react'
import { Text, View } from 'react-native'

export default  function Home():any{
    return(
      <View>
        <Text> textInComponent </Text>
      </View>
    )
  }
 
