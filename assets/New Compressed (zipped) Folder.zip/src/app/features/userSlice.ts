import { createSlice } from "@reduxjs/toolkit/dist/createSlice";
const name:string ='user'
const initialState:{}[]=[]
const userSlice=createSlice({
          name,
          initialState,
          reducers:{
              logIn:(state,action)=>{},
              logOut:(state,action)=>{},
              registration:(state,action)=>{},
          },

});
export const{logIn,logOut,registration}=userSlice.actions;
export default userSlice.reducer;
